function v2() {
    window.location.href = "https://my-gopage.netlify.app/";
}

function v1() {
    window.location.href = "https://my-gopage.netlify.app/info/version/original";
}