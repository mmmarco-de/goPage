var url;
function run() {
  url = 'https://www.qwant.com/?q=' + document.getElementById('inp').value;
  window.location = url;
};