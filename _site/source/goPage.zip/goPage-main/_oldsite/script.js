function google() {
  window.location = /google/;
};

function bing() {
  window.location = /bing/;
};

function duckduckgo() {
  window.location = /duckduckgo/;
};

function yandex() {
  window.location = /yandex/;
};

function ecosia() {
  window.location = /ecosia/;
};

function qwant() {
  window.location = /qwant/;
};